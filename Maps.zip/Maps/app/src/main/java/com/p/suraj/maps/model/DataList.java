package com.p.suraj.maps.model;

/**
 * Created by Saumitra on 12/2/2018.
 */
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class DataList {
    @SerializedName("notice_list")
    private ArrayList<Data> noticeList;

    public ArrayList<Data> getNoticeArrayList() {
        return noticeList;
    }

    public void setNoticeArrayList(ArrayList<Data> noticeArrayList) {
        this.noticeList = noticeArrayList;
    }
}

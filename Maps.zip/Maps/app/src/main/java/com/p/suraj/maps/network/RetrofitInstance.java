package com.p.suraj.maps.network;

/**
 * Created by Saumitra on 12/2/2018.
 */

import android.net.Uri;

import com.p.suraj.maps.R;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitInstance {

    private static Retrofit retrofit;
    private static final String BASE_URL = "https://api.myjson.com/";

    //static String video = "android.resource://com.p.suraj.maps.R.raw.jsondemo.json";
    /**
     * Create an instance of Retrofit objectgetResources().openRawResource(R.raw.filename)
     * */
    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
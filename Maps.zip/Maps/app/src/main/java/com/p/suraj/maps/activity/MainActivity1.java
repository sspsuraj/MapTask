package com.p.suraj.maps.activity;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.p.suraj.maps.R;
import com.p.suraj.maps.adapter.DataAdapter;
import com.p.suraj.maps.model.Data;
import com.p.suraj.maps.model.DataList;
import com.p.suraj.maps.my_interface.GetNoticeDataService;
import com.p.suraj.maps.network.RetrofitInstance;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity1 extends AppCompatActivity implements OnMapReadyCallback {

    private DataAdapter adapter1;
    private RecyclerView recyclerView;

   public  ArrayList latlong  = new ArrayList<>();
    SupportMapFragment mapFragment;
    private static GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        /** Create handle for the RetrofitInstance interface*/
        GetNoticeDataService service = RetrofitInstance.getRetrofitInstance().create(GetNoticeDataService.class);

        /** Call the method with parameter in the interface to get the notice data*/
        Call<DataList> call = service.getNoticeData();

        /**Log the URL called*/
        Log.wtf("URL Called", call.request().url() + "");

        call.enqueue(new Callback<DataList>() {

            @Override
            public void onResponse(Call<DataList> call, Response<DataList> response) {
                ArrayList<Data> jsonString1 = stringFromAsset1(MainActivity1.this, "data.json");
                try {
                   // Toast.makeText(MainActivity.this, "working"+jsonString1, Toast.LENGTH_SHORT).show();

                    //JSONObject jsonObject = new JSONObject(jsonString);
                 //   ArrayList<Notice> studentArray = loadJSONFromAsset();
                   // Toast.makeText(MainActivity.this, ""+studentArray, Toast.LENGTH_SHORT).show();
                  //  Type type = new TypeToken<ArrayList<Notice>>(){}.getType();
                   // cities1 = gson.fromJson(jsonString, type);
                    //Toast.makeText(MainActivity.this, ""+cities, Toast.LENGTH_SHORT).show();
                    generateDataList(jsonString1);
                  // String result = "";

                    // txtJson.setText(result);
                } catch (Exception e) {
                    Log.d("ReadPlacesFeedTask", e.getLocalizedMessage());
                }

            }

            @Override
            public void onFailure(Call<DataList> call, Throwable t) {
                Toast.makeText(MainActivity1.this, "Something went wrong...Error message: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void generateDataList(ArrayList<Data> noticeArrayList) {
         //latlong = null;
        for (int i = 0; i < noticeArrayList.size(); i++) {

             //Toast.makeText(this, ""+i, Toast.LENGTH_SHORT).show();
            try {
                String g = noticeArrayList.get(i).getLatitude()+"  , "+noticeArrayList.get(i).getLongitude();
               latlong.add(g);
                current();
                //Toast.makeText(this, ""+latlong, Toast.LENGTH_SHORT).show();
               // Toast.makeText(this, ""+noticeArrayList.get(i).getLatitude()+"  , "+noticeArrayList.get(i).getLongitude(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        recyclerView = findViewById(R.id.recycler_view_notice_list);
        DataAdapter.context= MainActivity1.this;
        adapter1 = new DataAdapter(noticeArrayList);
     //   Toast.makeText(this, "working fine:"+adapter1, Toast.LENGTH_SHORT).show();
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        // userReminderRecyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setNestedScrollingEnabled(true);
        //   Toast.makeText(this, ""+adapter1, Toast.LENGTH_SHORT).show();
        try {
            recyclerView.setAdapter(adapter1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static ArrayList<Data> stringFromAsset1(Context context, String assetFileName) {
        AssetManager am = context.getAssets();
        ArrayList<Data> studentArray = new ArrayList<>();

        try {
            InputStream is = am.open(assetFileName);
            int size = is.available();
            byte[] buffer = new byte[size];
           // Toast.makeText(context, ""+buffer, Toast.LENGTH_SHORT).show();
            is.read(buffer);
            is.close();
            String  json = new String(buffer, "UTF-8");
            //  Toast.makeText(context, ""+json, Toast.LENGTH_SHORT).show();
            JSONObject obj = new JSONObject(json);
            JSONArray m_jArry = obj.getJSONArray("data");
            //Toast.makeText(context, "working"+m_jArry, Toast.LENGTH_SHORT).show();
            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);
                Data student = new Data();
                student.setTitle(jo_inside.getString("title"));
                student.setLatitude(jo_inside.getString("latitude"));
                student.setLongitude(jo_inside.getString("longitude"));
                studentArray.add(student);
                //Toast.makeText(context, "ok"+studentArray, Toast.LENGTH_SHORT).show();

            }
            //String result = stringFromStream(is);
            // is.close();
          //  Toast.makeText(context, ""+studentArray.get(1), Toast.LENGTH_SHORT).show();
            return studentArray;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String stringFromStream(InputStream is) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;

            while ((line = reader.readLine()) != null)
                sb.append(line).append("\n");
            reader.close();
            return sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;


    }

    public  void current(){

        {

            //Getting longitude and latitude

            //Adding marker to map
            for(Object s : latlong){

                String[] ds =  s.toString().split(",");
                //Toast.makeText(this, "  ll "+ds[0]+","+ds[1], Toast.LENGTH_SHORT).show();

                //Integer i = Integer.parseInt(ds[0]);
               // Integer j = Integer.parseInt(ds[1]);

                LatLng sydney1 = new LatLng(Double.parseDouble(ds[0]), Double.parseDouble(ds[1]));
             //   Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
                mMap.addMarker(new MarkerOptions().position(sydney1).icon(BitmapDescriptorFactory.fromResource(R.drawable.placehol))
                    );
                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney1));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(sydney1,14));
            }


        }
    }
}

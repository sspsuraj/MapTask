package com.p.suraj.maps.adapter;

/**
 * Created by Saumitra on 12/2/2018.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.p.suraj.maps.R;
import com.p.suraj.maps.model.Data;
import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.NoticeViewHolder> {

    private ArrayList<Data> dataList;
    ArrayList<String> latl;

    public static Context context;
    public DataAdapter(ArrayList<Data> dataList) {
        this.dataList = dataList;
    }

    @Override
    public NoticeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.single_view_row, parent, false);
        return new NoticeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NoticeViewHolder holder, int position) {
        holder.title.setText(dataList.get(position).getTitle());
        holder.latitude.setText(dataList.get(position).getLatitude()+"  ,  "+dataList.get(position).getLongitude());
      //  latl.add(dataList.get(position).getLatitude()+"  ,  "+dataList.get(position).getLongitude());
        holder.longitude.setText(dataList.get(position).getLongitude());
      // Toast.makeText(context, ""+context, Toast.LENGTH_SHORT).show();
        Picasso.with(context).load(dataList.get(position).getImage()).into(holder.image);

       // new DownloadImageTask( holder.image).execute(dataList.get(position).getImage());

        try {
           // Toast.makeText(context, "its working fine :  "+dataList.get(position).getTitle(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    class NoticeViewHolder extends RecyclerView.ViewHolder {

        TextView title, latitude, longitude;
        ImageView image;
        NoticeViewHolder(View itemView) {
            super(itemView);
            title =  itemView.findViewById(R.id.txt_notice_title);
            latitude =  itemView.findViewById(R.id.txt_notice_brief);
            longitude =  itemView.findViewById(R.id.txt_notice_file_path);
            image = itemView.findViewById(R.id.image1);
        }
    }
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap bmp = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                bmp = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
          //
            return bmp;
        }
        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }
}

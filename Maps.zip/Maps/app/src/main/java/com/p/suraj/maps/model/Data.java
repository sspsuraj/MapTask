package com.p.suraj.maps.model;

/**
 * Created by Saumitra on 12/2/2018.
 */

public class Data {
    String image,latitude,longitude,title;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Data() {

    }

    public Data(String image, String latitude, String longitude, String title) {

        this.image = image;
        this.latitude = latitude;
        this.longitude = longitude;
        this.title = title;
    }
}
